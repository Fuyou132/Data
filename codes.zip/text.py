import torch
import pandas as pd
from dataset import MyDataset
from model import UACNet
from torchinfo import summary
from torch.utils.data import DataLoader

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")  # device selection
uac_net = UACNet().to(DEVICE)
# 加载模型权重
model_path = r'G:\one\Finally\MSINet-UCA\UACNet-best-epoch-16-accuracy100.00.pkl'
model = uac_net  # 替换为您自己的模型类
model.load_state_dict(torch.load(model_path))

# 设置设备
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model.to(device)

# 定义损失函数和测试数据加载器
test_loader = DataLoader(MyDataset(r'./data/', train=False), batch_size=1, shuffle=False)  # 替换为您自己的测试数据加载器

celoss = torch.nn.CrossEntropyLoss()

model.eval()
test_loss = 0
correct = 0

with open(f'G:\one\Finally\\test_results_-5.txt', 'w') as f:
    f.write('')

with torch.no_grad():
    for data, target in test_loader:
        data, target = data.to(device), target.to(device)
        output = model(data.float())
        output = output.unsqueeze(0)
        test_loss += celoss(output, target).item()
        pred = output.argmax(dim=1)
        correct += pred.eq(target).sum().item()
        with open(f'G:\one\Finally\\test_results_-5.txt', 'a+') as f:
            for t, p in zip(target.cpu(), pred.cpu()):
                f.write(f'{t.item()}, {p.item()}\n')

test_loss /= len(test_loader.dataset)
accuracy = 100. * correct / len(test_loader.dataset)
print('\nTest set: Average loss: {:.4f}, Accuracy: {}/{} ({:.2f}%)\n'.format(
    test_loss, correct, len(test_loader.dataset),
    accuracy))
