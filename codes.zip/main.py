import torch
import pandas as pd
from dataset import MyDataset
from model import UACNet
from torchinfo import summary
from torch.utils.data import DataLoader
from train_process import train_process
from test_process import test_process
import torch.nn as nn
import os
from torchvision.utils import make_grid
import numpy as np
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE

'''Super parameters''' 
EPOCHS = 100
learning_rate = 0.0001
START_EPOCH = 0

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")  # device selection

'''Load dataset'''
train_loader = DataLoader(MyDataset(r'./data/'), batch_size=1, shuffle=True)
test_loader = DataLoader(MyDataset(r'./data/', train=False), batch_size=1, shuffle=False)

uac_net = UACNet().to(DEVICE)

# optimizer = torch.optim.SGD(uac_net.parameters(), lr=learning_rate, weight_decay=1)
optimizer = torch.optim.SGD(uac_net.parameters(), lr=learning_rate, weight_decay=0.0001)
scheduler = torch.optim.lr_scheduler.StepLR(optimizer, 20, gamma=0.1, last_epoch=-1)
CELoss = nn.CrossEntropyLoss()

best_accuracy = 0.0
best_epoch = 0

# print(summary(uac_net, input_size=(1, 1, 6000)))打印学习率信息，并检查是否存在之前训练的检查点。如果存在，加载之前训练的模型参数。
print(f'learning_rate={learning_rate}')
if START_EPOCH != 0:
    uac_net.load_state_dict(torch.load('./results/checkpoints/UACNet-epoch-' + str(START_EPOCH).zfill(3) + '.pkl'))

# uac_net.eval()

with open('./results/test_results/train_losses.txt', 'w') as f:
    f.write('')

for epoch in range(START_EPOCH, EPOCHS):
    #创建当前epoch文件夹
    #epoch_folder = os.path.join(result_folder, f'epoch_{epoch}')
    #os.makedirs(epoch_folder, exist_ok=True)

    train_process(uac_net, DEVICE, train_loader, optimizer, epoch, CELoss)
    scheduler.step()
    if (epoch + 1) % 1 == 0:
        accuracy = test_process(uac_net, DEVICE, test_loader, epoch, CELoss)
        if accuracy > best_accuracy:
            best_accuracy = accuracy
            best_epoch = epoch
            torch.save(uac_net.state_dict(), "./results/checkpoints/UACNet-best-epoch-{}-accuracy{:.2f}.pkl".format(best_epoch, best_accuracy))


'''
# 获取特征向量和注意力图
def get_features_and_attention(model, device, data_loader):
    model.eval()
    features = []
    attention_maps = []
    with torch.no_grad():
        for wave, label in data_loader:
            wave = wave.to(device)
            features_batch, attention_maps_batch = model.get_features_and_attention(wave.float())
            features.append(features_batch)
            attention_maps.append(attention_maps_batch)
    features = torch.cat(features, dim=0).cpu().numpy()
    attention_maps = torch.cat(attention_maps, dim=0).cpu().numpy()
    return features, attention_maps

#result_folder = './results/epoch_results'
#os.makedirs(result_folder, exist_ok=True)
'''
'''
 # 在训练过程结束后，获取特征向量和注意力图
            # 获取特征向量和注意力权重
            features, labels = uac_net.get_features_and_attention(DEVICE, train_loader)

            # 创建颜色映射，用于区分不同类别
            color_map = plt.cm.get_cmap('tab10')

            # 绘制特征向量
            for i, feature in enumerate(features):
                label = labels[i]

                color = color_map(label)
                plt.plot(feature, color=color, label=f"Class {label}")

            plt.title("Feature Visualization")
            plt.xlabel("Index")
            plt.ylabel("Value")
            plt.legend()
            plt.savefig(os.path.join(epoch_folder, 'features.png'))
            plt.close()
'''